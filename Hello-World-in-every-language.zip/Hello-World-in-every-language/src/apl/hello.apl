⎕←'Hello, World!'
